const API = window.location.origin;

function showToast(msg, isError = true) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.className = 'toast show' + (isError ? ' error' : '');
  setTimeout(() => t.classList.remove('show'), 3200);
}

function getToken() {
  return localStorage.getItem('xeon_token');
}

function authHeaders() {
  return {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + getToken()
  };
}

async function doLogin() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  if (!username || !password) return showToast('Fill all fields');

  try {
    const res = await fetch(API + '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!data.success) return showToast(data.message || 'Login failed');

    localStorage.setItem('xeon_token', data.token);
    localStorage.setItem('xeon_user', data.username);
    localStorage.setItem('xeon_expiry', data.expiry || '');
    location.href = 'dashboard.html';
  } catch {
    showToast('Connection error');
  }
}

async function loadDashboard() {
  if (!getToken()) return location.href = 'index.html';

  document.getElementById('user-name').textContent = localStorage.getItem('xeon_user') || 'User';

  const exp = localStorage.getItem('xeon_expiry');
  if (exp) {
    document.getElementById('expiry-text').style.display = 'block';
    document.getElementById('expiry-text').textContent = 'Expires: ' + new Date(exp).toLocaleString();
  }

  // Status
  try {
    const r = await fetch(API + '/api/status');
    const d = await r.json();
    const dot = document.getElementById('status-dot');
    const txt = document.getElementById('status-text');
    if (d.active) {
      dot.className = 'dot on';
      txt.textContent = 'ACTIVE';
      txt.style.color = '#00ff9d';
    } else {
      dot.className = 'dot off';
      txt.textContent = 'MAINTENANCE';
      txt.style.color = '#ff4d4d';
    }
  } catch {}

  // Usage
  try {
    const r = await fetch(API + '/api/usage', { headers: authHeaders() });
    const d = await r.json();
    document.getElementById('c-android').textContent = d.android || 0;
    document.getElementById('c-ios').textContent = d.ios || 0;
    document.getElementById('c-group').textContent = d.group || 0;
  } catch {}
}

async function sendGreeting(type) {
  const input = document.getElementById('target');
  let target = input.value.trim();
  if (!target) return showToast('Enter target');

  if (type !== 'group') {
    target = target.replace(/[^0-9]/g, '');
    if (target.length < 8 || target.length > 15) return showToast('Invalid number');
  }

  const btn = document.getElementById('send-btn');
  btn.disabled = true;
  btn.textContent = 'SENDING...';

  try {
    const res = await fetch(API + `/api/greeting/${type}`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ target })
    });
    const data = await res.json();

    if (data.success) {
      showToast('Sent successfully', false);
      addLine(`${type.toUpperCase()} → ${target} ✓`, true);
    } else {
      showToast(data.message || 'Failed');
      addLine(`${type.toUpperCase()} → ${target} ✗`, false);
    }
  } catch {
    showToast('Server error');
  }

  btn.disabled = false;
  btn.textContent = 'EXECUTE';
}

function addLine(text, ok) {
  const box = document.getElementById('console');
  if (!box) return;
  const div = document.createElement('div');
  div.className = 'console-line ' + (ok ? 'ok' : 'err');
  div.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
  box.prepend(div);
}

function logout() {
  localStorage.clear();
  location.href = 'index.html';
}

function toggleMenu() {
  document.getElementById('sidebar').classList.toggle('open');
}

// Close drawer when clicking outside
document.addEventListener('click', function(e) {
  const sidebar = document.getElementById('sidebar');
  const menuBtn = document.querySelector('.menu-btn');

  if (!sidebar || !menuBtn) return;

  // If sidebar is open and click is outside sidebar and outside menu button
  if (sidebar.classList.contains('open')) {
    if (!sidebar.contains(e.target) && !menuBtn.contains(e.target)) {
      sidebar.classList.remove('open');
    }
  }
});